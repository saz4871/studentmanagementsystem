/**
 * 
 */
/**
 * 
 */
module studentmanagementsystem {
	requires java.desktop;
	requires java.sql;
	requires mysql.connector.j;
	requires ojdbc7;
}